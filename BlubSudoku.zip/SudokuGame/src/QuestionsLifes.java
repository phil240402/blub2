import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class QuestionsLifes {
    private int lives;
    private JSONArray questions;

    public QuestionsLifes(int initialLives, String filePath) throws IOException, JSONException, URISyntaxException {
        this.lives = initialLives;

        Path path = Paths.get(QuestionsLifes.class.getClassLoader().getResource(filePath).toURI());
        String content = new String(Files.readAllBytes(path));

        this.questions = new JSONArray(content);
    }

    public int getLives() {
        return lives;
    }

    public JSONObject getRandomQuestion() throws JSONException {
        return questions.getJSONObject((int)(Math.random() * questions.length()));
    }

    public boolean isAnswerCorrect(JSONObject question, String userAnswer) throws JSONException {
        JSONArray acceptableAnswers = question.getJSONArray("answer");
        for (int i = 0; i < acceptableAnswers.length(); i++) {
            if (levenshteinDistance(userAnswer, acceptableAnswers.getString(i)) <= 2) {
                return true;
            }
        }
        return false;
    }

    public void decrementLives() {
        this.lives -= 1;
    }

    public static int levenshteinDistance(CharSequence lhs, CharSequence rhs) {
        int len0 = lhs.length() + 1;
        int len1 = rhs.length() + 1;
        int[] cost = new int[len0];
        int[] newcost = new int[len0];
        for (int i = 0; i < len0; i++) {
            cost[i] = i;
        }
        for (int j = 1; j < len1; j++) {
            newcost[0] = j;
            for(int i = 1; i < len0; i++) {
                int match = (lhs.charAt(i - 1) == rhs.charAt(j - 1)) ? 0 : 1;
                int cost_replace = cost[i - 1] + match;
                int cost_insert  = cost[i] + 1;
                int cost_delete  = newcost[i - 1] + 1;
                newcost[i] = Math.min(Math.min(cost_insert, cost_delete), cost_replace);
            }
            int[] swap = cost; cost = newcost; newcost = swap;
        }
        return cost[len0 - 1];
    }
}
