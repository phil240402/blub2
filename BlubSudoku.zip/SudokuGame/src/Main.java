import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

public class Main {
    public static void main(String[] args) {
        try {
            QuestionsLifes questionsLifes = new QuestionsLifes(3, "questions.json");
            Scanner scanner = new Scanner(System.in);

            while (questionsLifes.getLives() > 0) {
                JSONObject question = questionsLifes.getRandomQuestion();
                System.out.println(question.getString("question"));

                String userAnswer = scanner.nextLine();
                if (questionsLifes.isAnswerCorrect(question, userAnswer)) {
                    System.out.println("Correct answer! You still have " + questionsLifes.getLives() + " lives.");
                } else {
                    questionsLifes.decrementLives();
                    if (questionsLifes.getLives() == 0) {
                        System.out.println("Game Over");
                    } else {
                        System.out.println("Wrong answer! You now have " + questionsLifes.getLives() + " lives.");
                    }
                }
            }

            scanner.close();
        } catch (IOException | JSONException | URISyntaxException e) {
            e.printStackTrace();
        }
    }
}
