import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class Main {

    public static void main(String[] args) {
        SudokuSolver solver = new SudokuSolver();

        // Generate a new puzzle
        solver.generatePuzzle();
        int[][] solvedPuzzle = new int[SudokuSolver.SIZE][SudokuSolver.SIZE];
        for (int r = 0; r < SudokuSolver.SIZE; r++) {
            solvedPuzzle[r] = solver.getBoard()[r].clone();
        }

        // Create user board
        int[][] userPuzzle = new int[SudokuSolver.SIZE][SudokuSolver.SIZE];
        for (int r = 0; r < SudokuSolver.SIZE; r++) {
            userPuzzle[r] = solver.getBoard()[r].clone();
        }

        // Remove some numbers from the user's puzzle
        int cellsToRemove = 30;  // remove 30 cells
        while (cellsToRemove > 0) {
            int row = solver.getRandom().nextInt(SudokuSolver.SIZE);
            int col = solver.getRandom().nextInt(SudokuSolver.SIZE);
            if (userPuzzle[row][col] != 0) {
                userPuzzle[row][col] = 0;
                cellsToRemove--;
            }
        }

        // User interaction
        Scanner scanner = new Scanner(System.in);
        while (true) {
            // Print the user's current puzzle
            System.out.println("\nCurrent puzzle:");
            solver.printBoard(userPuzzle);

            // Ask the user for input
            System.out.println("Enter the row, column, and number (1-based) to fill, separated by spaces (e.g., '5 7 3' to fill row 5, column 7 with 3), or 'quit' to stop:");

            String input = scanner.nextLine();
            if ("quit".equalsIgnoreCase(input)) {
                break;
            }

            String[] parts = input.split(" ");
            int row = Integer.parseInt(parts[0]) - 1;
            int col = Integer.parseInt(parts[1]) - 1;
            int num = Integer.parseInt(parts[2]);

            if (solvedPuzzle[row][col] == num) {
                userPuzzle[row][col] = num;
                System.out.println("Correct entry!");
            } else {
                System.out.println("Wrong entry.");
            }
        }

        scanner.close();
    }
}
